Use master
Go

PRINT '';
PRINT '*** Dropping Database';
GO

IF EXISTS (SELECT [name] FROM [master].[sys].[databases] WHERE [name] = N'AdultIncome')
DROP DATABASE AdultIncome;
GO

PRINT '';
PRINT '*** Creating Database';
GO

Create database AdultIncome
Go

Use AdultIncome
Go

PRINT '';
PRINT '*** Creating Table FactAdultIncome';
GO

Create Table FactAdultIncome
(

ID int primary key identity,
WorkClassID int not null,
EduID int not null,
MaritalID int not null,
RaceID int not null,
IncomeID int not null,
OccupationID int not null,
NativeCountryID int not null,
GenderID int not null,
Age int,
HourlyWage int,
Counts int,
AgeCounts int,
WageCounts int
)
Go

PRINT '';
PRINT '*** Creating Table DimWorkClass';
GO

Create table DimWorkClass
(
WorkClassID int primary key identity,
WorkClass varchar(20),
GovPri varchar(20),
Employed varchar(20)
)
Go

PRINT '';
PRINT '*** Creating Table DimEdu';
GO

Create table DimEdu
(
EduID int primary key identity,
Edu varchar(20),
EduLvl varchar(30)
)
Go

PRINT '';
PRINT '*** Creating Table DimMarital';
GO

Create table DimMarital
(
MaritalID int primary key identity,
Marital varchar(30),
MarSin varchar(30)
)
Go

PRINT '';
PRINT '*** Creating Table DimRace';
GO

Create table DimRace
(
RaceID int primary key identity,
Race varchar(30)
)
Go

PRINT '';
PRINT '*** Creating Table DimIncome';
GO

Create table DimIncome
(
IncomeID int primary key identity,
Income varchar(10)
)
GO

PRINT '';
PRINT '*** Creating Table DimOccupation';
GO

Create table DimOccupation
(
OccupationID int primary key identity,
Occupation varchar(50)
)
GO

PRINT '';
PRINT '*** Creating Table DimNative';
GO

Create table DimNative
(
NativeCountryID int primary key identity,
NativeCountry varchar(50),
Continent varchar(50),
usNonUS varchar(10)
)
GO

PRINT '';
PRINT '*** Creating Table DimGender';
GO

Create table DimGender
(
GenderID int primary key identity,
Gender varchar(10)
)
GO


PRINT '';
PRINT '*** Add relation between fact table foreign keys to Primary keys of Dimensions';
GO

AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_WorkClass FOREIGN KEY (WorkClassID)REFERENCES DimWorkClass(WorkClassID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Edu FOREIGN KEY (EduID)REFERENCES DimEdu(EduID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Marital FOREIGN KEY (MaritalID)REFERENCES DimMarital(MaritalID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Race FOREIGN KEY (RaceID)REFERENCES DimRace(RaceID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Income FOREIGN KEY (IncomeID)REFERENCES DimIncome(IncomeID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Occupation FOREIGN KEY (OccupationID)REFERENCES DimOccupation(OccupationID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Native FOREIGN KEY (NativeCountryID)REFERENCES DimNative(NativeCountryID);
AlTER TABLE FactAdultIncome ADD CONSTRAINT 
FK_Gender FOREIGN KEY (GenderID)REFERENCES DimGender(GenderID);
Go

