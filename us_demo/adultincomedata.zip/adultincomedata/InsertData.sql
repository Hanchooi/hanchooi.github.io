:SETVAR DatabaseName adultincomedata

:SETVAR SqlSamplesSourceDataPath C:\Samples\adultincomedata\


BULK INSERT [dbo].[DimWorkClass] FROM '$(SqlSamplesSourceDataPath)DimWorkClass.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
	DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimEdu] FROM '$(SqlSamplesSourceDataPath)DimEdu.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimMarital] FROM '$(SqlSamplesSourceDataPath)DimMarital.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimRace] FROM '$(SqlSamplesSourceDataPath)DimRace.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimIncome] FROM '$(SqlSamplesSourceDataPath)DimIncome.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimOccupation] FROM '$(SqlSamplesSourceDataPath)DimOccupation.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimNative] FROM '$(SqlSamplesSourceDataPath)DimNative.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimGender] FROM '$(SqlSamplesSourceDataPath)DimGender.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);


BULK INSERT [dbo].[FactAdultIncome] FROM '$(SqlSamplesSourceDataPath)FactIncome.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
	FIRSTROW = 2,
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);
